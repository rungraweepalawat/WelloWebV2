Wello production build
Static site entry point: index.html
